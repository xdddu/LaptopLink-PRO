const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const path = require("path");

const app = express();
app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true, name: "LaptopLink PRO" }));

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const rooms = new Map();

function send(ws, obj) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}
function leave(ws) {
  if (!ws.room) return;
  const members = rooms.get(ws.room);
  if (members) {
    members.delete(ws);
    for (const peer of members) send(peer, { type: "peer-left" });
    if (!members.size) rooms.delete(ws.room);
  }
  ws.room = null;
}
wss.on("connection", ws => {
  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (msg.type === "join") {
      const room = String(msg.room || "").trim().toUpperCase();
      if (!/^[A-Z0-9-]{4,20}$/.test(room)) return send(ws, {type:"error", message:"Код комнаты должен содержать 4–20 латинских букв, цифр или дефисов."});
      leave(ws);
      let members = rooms.get(room);
      if (!members) { members = new Set(); rooms.set(room, members); }
      if (members.size >= 2) return send(ws, {type:"error", message:"В этой комнате уже два устройства."});
      ws.room = room;
      members.add(ws);
      send(ws, {type:"joined", room, peers: members.size - 1});
      if (members.size === 2) {
        const peers = [...members];
        send(peers[0], {type:"peer-ready", initiator:true});
        send(peers[1], {type:"peer-ready", initiator:false});
      }
      return;
    }
    if (!ws.room) return;
    const members = rooms.get(ws.room);
    if (!members) return;
    for (const peer of members) if (peer !== ws) send(peer, msg);
  });
  ws.on("close", () => leave(ws));
  ws.on("error", () => leave(ws));
});
const port = process.env.PORT || 3000;
server.listen(port, "0.0.0.0", () => console.log(`LaptopLink PRO listening on ${port}`));
